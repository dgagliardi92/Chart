jQuery.sap.declare("com.softtek.Chart.Component");

/*sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/softtek/Chart/model/models"
], function (UIComponent, Device, models) {
	"use strict";*/
	sap.ui.core.UIComponent.extend( "com.softtek.Chart.Component" , {
	//return UIComponent.extend("com.softtek.Chart.Component", {

		metadata: {
			manifest: "json"
		},
		
		createContent: function () {
			// create root view
			this.view = sap.ui.view({
				id: "app",
				viewName: "com.softtek.Chart.view.chart",
				type: sap.ui.core.mvc.ViewType.XML,
				viewData: {
					component: this
				}
			});
			return this.view;
		},

		init: function () {
			//sap.ui.localResources("https://sapui5.hana.ondemand.com/resources/sap-ui-core.js");
			//jQuery.sap.registerModulePath("sap.ui.codetools", "/sap/ui/codetools/");

			
			
			sap.ui.core.UIComponent.prototype.init.apply(this, arguments);
			this.getRouter().initialize();
			//this.setModel(models.createDeviceModel(), "device");
		},
		
		destroy: function() {
			
			//this._oErrorHandler.destroy();
			sap.ui.core.UIComponent.prototype.destroy.apply(this, arguments);
		}
	}
	);
/*});*/